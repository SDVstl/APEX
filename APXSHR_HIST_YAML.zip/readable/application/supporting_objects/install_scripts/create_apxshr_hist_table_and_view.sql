  /*
    This table and view may already exist if you installed the PGMOPT or APXSHR_SHARED_LOVS apps.
  */
  CREATE SEQUENCE  "APXSHR_HISTORY_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1 NOCACHE  NOORDER  NOCYCLE  NOKEEP  NOSCALE  GLOBAL ;

  CREATE TABLE "APXSHR_HISTORY" 
   (	"ID" NUMBER, 
	"TABLE_NAME" VARCHAR2(128), 
	"COLUMN_NAME" VARCHAR2(128), 
	"ACTION" VARCHAR2(1), 
	"ACTION_DATE" DATE, 
	"ACTION_BY" VARCHAR2(255), 
	"DATA_TYPE" VARCHAR2(255), 
	"PK1" VARCHAR2(64), 
	"TAB_ROW_VERSION" NUMBER(*,0), 
	"OLD_VC" VARCHAR2(4000), 
	"NEW_VC" VARCHAR2(4000), 
	"OLD_NUMBER" NUMBER, 
	"NEW_NUMBER" NUMBER, 
	"OLD_DATE" DATE, 
	"NEW_DATE" DATE, 
	"OLD_TS" TIMESTAMP (6), 
	"NEW_TS" TIMESTAMP (6), 
	"OLD_TSWTZ" TIMESTAMP (6) WITH TIME ZONE, 
	"NEW_TSWTZ" TIMESTAMP (6) WITH TIME ZONE, 
	"OLD_TSWLTZ" TIMESTAMP (6) WITH LOCAL TIME ZONE, 
	"NEW_TSWLTZ" TIMESTAMP (6) WITH LOCAL TIME ZONE, 
	"OLD_CLOB" CLOB, 
	"NEW_CLOB" CLOB, 
	"OLD_BLOB" BLOB, 
	"NEW_BLOB" BLOB, 
	"ASOF_TS" DATE DEFAULT SYSDATE, 
	 CHECK (action in ('I','U','D')) ENABLE, 
	 PRIMARY KEY ("ID")
  USING INDEX  ENABLE
   ) ;

CREATE INDEX "APXSHR_HISTORY_IDX1" ON "APXSHR_HISTORY" ("COLUMN_NAME");

CREATE INDEX "APXSHR_HISTORY_INDX2" ON "APXSHR_HISTORY" ("PK1");

CREATE INDEX "APXSHR_HISTORY_IDX3" ON "APXSHR_HISTORY" ("ASOF_TS");

CREATE OR REPLACE FORCE EDITIONABLE VIEW "APXSHR_HISTORY_V" ("ID", "TABLE_NAME", "COLUMN_NAME", "ACTION", "ACTION_DATE", "ACTION_BY", "TABLE_PRIMARY_KEY", "TABLE_ROW_VERSION", "CHANGE") AS 
  SELECT id,
           table_name,
           column_name,
           DECODE (action,  'U', 'Update',  'D', 'Delete')
               action,
           action_date,
           action_by,
           pk1
               table_primary_key,
           tab_row_version
               table_row_version,
           DECODE (
               data_type,
               'NUMBER', old_number || ' > ' || new_number,
               'VARCHAR2',    SUBSTR (old_vc, 1, 50)
                           || ' > '
                           || SUBSTR (new_vc, 1, 50),
               'DATE',    TO_CHAR (old_date, 'YYYYMMDD HH24:MI:SS')
                       || ' > '
                       || TO_CHAR (new_date, 'YYYYMMDD HH24:MI:SS'),
               'TIMESTAMP',    TO_CHAR (old_ts, 'YYYYMMDD HH24:MI:SS')
                            || ' > '
                            || TO_CHAR (new_ts, 'YYYYMMDD HH24:MI:SS'),
               'TIMESTAMP WITH TIMEZONE',    TO_CHAR (old_tswtz,
                                                      'YYYYMMDD HH24:MI:SS')
                                          || ' > '
                                          || TO_CHAR (new_tswtz,
                                                      'YYYYMMDD HH24:MI:SS'),
               'TIMESTAMP WITH LOCAL TIMEZONE',    TO_CHAR (
                                                       old_tswltz,
                                                       'YYYYMMDD HH24:MI:SS')
                                                || ' > '
                                                || TO_CHAR (
                                                       new_tswltz,
                                                       'YYYYMMDD HH24:MI:SS'),
               'BLOB',    'length '
                       || sys.DBMS_LOB.getlength (old_blob)
                       || ' > '
                       || ' length '
                       || sys.DBMS_LOB.getlength (new_blob),
               'CLOB',    sys.DBMS_LOB.SUBSTR (old_clob, 50, 1)
                       || ' > '
                       || sys.DBMS_LOB.SUBSTR (new_clob, 50, 1))
               change
      FROM apxshr_history
;