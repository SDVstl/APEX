create or replace package APXSHR_HIST_PKG as
    TYPE  APXSHR_VC_ARRAY_1 is TABLE OF VARCHAR2(100);

    function GEN_HIST_AUD_TRIGGER
        ( schema_in             in VARCHAR2 default NULL, 
          prefix_in             in VARCHAR2 default NULL, 
          table_in              in VARCHAR2 default NULL, 
          table_pk_col_name_in  in VARCHAR2 default 'ID', 
          create_hist_table     in VARCHAR2 default 'Y', 
          create_aud_trigger    in VARCHAR2 default 'Y' ) return CLOB;

    function pipelined_list ( p_string    in VARCHAR2,   
                              p_delimiter in VARCHAR2 DEFAULT ',')  RETURN apxshr_vc_array_1 PIPELINED;           

end APXSHR_HIST_PKG;
/
create or replace package body APXSHR_HIST_PKG as

function pipelined_list       (p_string    in VARCHAR2,       
                               p_delimiter in VARCHAR2 DEFAULT ',') RETURN apxshr_vc_array_1 PIPELINED IS       
           
    l_string varchar2(32000);       
--    l_array  wwv_flow_global.vc_arr2;  -- deprecated     
    l_array  apex_t_varchar2;     
       
begin       
           
   if p_string IS NULL        
   then        
        return;        
   end if;  -- prevent error if nothing is passed       
       
--   l_array := apex_util.STRING_TO_TABLE (p_string,p_delimiter);   -- deprecated     
   l_array := apex_string.split(p_string,p_delimiter);      
       
--   for i in l_array.first..l_array.last        
   for i in 1..l_array.count     
   loop       
      pipe row (trim(l_array(i)));       
   end loop;       
          
   return;       
       
end pipelined_list;  

function GEN_HIST_AUD_TRIGGER
    ( schema_in             in VARCHAR2 default NULL, 
      prefix_in             in VARCHAR2 default NULL, 
      table_in              in VARCHAR2 default NULL, 
      table_pk_col_name_in  in VARCHAR2 default 'ID', 
      create_hist_table     in VARCHAR2 default 'Y', 
      create_aud_trigger    in VARCHAR2 default 'Y' ) return CLOB is   
--------------------------------------------------------------------- 
---------------------------------------------------------------------       
-- variables and constants for the function    
    my_boolean BOOLEAN; 
    -- use the VARCHAR variables.  They must be free of any TABS.  Line feeds are required around '/' to generate separate SQL Statements 
    l_hist_table_tmplt      APXSHR_PGM_OPTIONS.OPT_VAL_VARCHAR%TYPE := APXSHR_PGM_OPTS.rtn_pgm_opt ('APXSHR_HIST', 1, 'text');  -- contains the template to create the *_HISTORY table    
    l_hist_table_seq_tmplt  APXSHR_PGM_OPTIONS.OPT_VAL_VARCHAR%TYPE := APXSHR_PGM_OPTS.rtn_pgm_opt ('APXSHR_HIST', 2, 'text');  -- contains the template to create the *_HISTORY_SEQ sequence 
    l_hist_view_seq_tmplt   APXSHR_PGM_OPTIONS.OPT_VAL_VARCHAR%TYPE := APXSHR_PGM_OPTS.rtn_pgm_opt ('APXSHR_HIST', 3, 'text');  -- contains the template to create the *_HISTORY_V view 
    l_aud_trgr_pt_1         APXSHR_PGM_OPTIONS.OPT_VAL_VARCHAR%TYPE := APXSHR_PGM_OPTS.rtn_pgm_opt ('APXSHR_HIST', 10, 'text'); -- contains the 1st part of trigger 
    l_aud_trgr_pt_2         APXSHR_PGM_OPTIONS.OPT_VAL_VARCHAR%TYPE := APXSHR_PGM_OPTS.rtn_pgm_opt ('APXSHR_HIST', 11, 'text'); -- contains the Update template. Repeated for each column. 
    l_aud_trgr_pt_3         APXSHR_PGM_OPTIONS.OPT_VAL_VARCHAR%TYPE := APXSHR_PGM_OPTS.rtn_pgm_opt ('APXSHR_HIST', 12, 'text'); -- contains the ELSIF between Update and Delete sections. 
    l_aud_trgr_pt_4         APXSHR_PGM_OPTIONS.OPT_VAL_VARCHAR%TYPE := APXSHR_PGM_OPTS.rtn_pgm_opt ('APXSHR_HIST', 13, 'text'); -- contains the Delete template. Repeated for each column.  
    l_aud_trgr_pt_5         APXSHR_PGM_OPTIONS.OPT_VAL_VARCHAR%TYPE := APXSHR_PGM_OPTS.rtn_pgm_opt ('APXSHR_HIST', 14, 'text'); -- contains the END of the trigger. 
    l_aud_trgr_pt_6         APXSHR_PGM_OPTIONS.OPT_VAL_VARCHAR%TYPE := APXSHR_PGM_OPTS.rtn_pgm_opt ('APXSHR_HIST', 16, 'text'); -- contains the Update template. Repeated for each column. BLOB/CLOB.     
    l_exclude_columns_lst   APXSHR_PGM_OPTIONS.OPT_VAL_VARCHAR%TYPE := APXSHR_PGM_OPTS.rtn_pgm_opt ('APXSHR_HIST', 15, 'text'); -- comma separated list of columns to exclude from trigger    
    l_aud_trgr_work         CLOB := NULL; 
    l_cr_lf                 VARCHAR2(50) := chr(13) || chr(10); 
    l_hist_table_DDL        CLOB := NULL; 
    l_hist_table_SEQ_DDL    VARCHAR2(4000) := NULL; 
    l_hist_view_DDL         CLOB := NULL; 
    l_hist_aud_trgr_DDL     CLOB := NULL; 
    l_RETURN_DDL            CLOB := NULL; 
    l_column_count          NUMBER := 0; 
     
    -- Associative array indexed by string to contain the Data Types and Abbreviations needed to build the AUD Trigger 
    TYPE abbreviations IS TABLE OF VARCHAR2(20)  -- Associative array type 
    INDEX BY VARCHAR2(64);                       -- indexed by string 
    data_type_abbr  abbreviations;               -- Associative array variable 
    i        VARCHAR2(64);                       -- Scalar variable         
         
-- end local variables 
 
-- local functions 
-- end local functions 
 
-- local procedures 
    procedure debug_it (text_in in varchar2) is
    begin
        apex_debug.info ( text_in ); 
        dbms_output.put_line ( text_in ); 
    end debug_it;

    procedure raise_app_error ( error_code_in in number, 
                                error_text_in in VARCHAR2 ) is 
    begin 
        raise_application_error (error_code_in, error_text_in); 
    end raise_app_error; 
 
    procedure load_data_type_abbr is 
    /* 
       use global arrays  
    */         
    begin 
        for C1 in ( 
            select 
                det.LOV_DISPLAY_VAL, 
                det.lov_display_desc, 
                det.ID 
            from APXSHR_LOV_DETAILS det 
            join APXSHR_LOV_NAME name on name.ID = det.LOV_NAME_ID and 
                name.APP_ALIAS = 'APXSHR_HIST' and 
                name.LOV_NA = 'Data Types and Abbreviations' 
            order by det.SORT_ORDER_NO, det.LOV_DISPLAY_VAL 
        ) 
        loop 
        -- Add elements (key-value pairs) to associative array: 
  
            data_type_abbr(C1.LOV_DISPLAY_VAL)  := C1.lov_display_desc; 
        end loop; 
         
        -- Print associative array (testing): 
        /* 
        i := data_type_abbr.FIRST;  -- Get first element of array 
  
        WHILE i IS NOT NULL  
        LOOP 
            DBMS_Output.PUT_LINE 
            ('Data Type Abbreviation of ' || i || ' is ' || data_type_abbr(i)); 
            i := data_type_abbr.NEXT(i);  -- Get next element of array 
        END LOOP; 
        */ 
    end load_data_type_abbr; 
 
-- end local procedures        
begin  -- "mainline" of GEN_HIST_AUD_TRIGGER 
    debug_it ('*** Starting GEN_HIST_AUD_TRIGGER ***'); 
 
    if  nvl(create_hist_table, 'N') = 'N' 
    and nvl(create_aud_trigger, 'N') = 'N'  
    then 
        raise_app_error (-20000, 'Invalid call to function, "create_hist_table" or "create_aud_trigger" must = ''Y''.'); 
        RETURN NULL; 
    end if; 
 
--  *** Generate History Table / View *** 
    if nvl(create_hist_table, 'N') = 'Y' 
    then 
        debug_it ('  Creating History Table / View'); 
 
        if prefix_in is NULL 
        then raise_app_error (-20001, 'Invalid call to function, must provide PREFIX when creating History TABLE.'); 
        end if; 
 
        if schema_in is NULL 
        then raise_app_error (-20004, 'Invalid call to function, must provide SCHEMA when creating History VIEW.'); 
        end if;         
 
        l_hist_table_seq_tmplt := replace (l_hist_table_seq_tmplt, '[PREFIX]', prefix_in); 
        l_hist_table_seq_tmplt := replace (l_hist_table_seq_tmplt, '[USER]', v('APP_USER')); 
        l_hist_table_seq_tmplt := replace (l_hist_table_seq_tmplt, '[DATE]', SYSDATE);   
        l_hist_table_seq_tmplt := replace (l_hist_table_seq_tmplt, '[APP_ID]', NV('APP_ID'));       
        l_hist_table_seq_tmplt := replace (l_hist_table_seq_tmplt, '[FUNCTION]', utl_call_stack.subprogram (1) (1) || '.' || utl_call_stack.subprogram (1) (2));                          
        l_hist_table_DDL       := l_hist_table_DDL || l_hist_table_seq_tmplt || l_cr_lf || l_cr_lf; 
 
        l_hist_table_tmplt     := replace (l_hist_table_tmplt, '[PREFIX]', prefix_in); 
        l_hist_table_tmplt     := replace (l_hist_table_tmplt, '[USER]', v('APP_USER')); 
        l_hist_table_tmplt     := replace (l_hist_table_tmplt, '[DATE]', SYSDATE);   
        l_hist_table_tmplt     := replace (l_hist_table_tmplt, '[APP_ID]', NV('APP_ID'));      
        l_hist_table_tmplt     := replace (l_hist_table_tmplt, '[FUNCTION]', utl_call_stack.subprogram (1) (1) || '.' || utl_call_stack.subprogram (1) (2));    
        l_hist_table_DDL       := l_hist_table_DDL || l_hist_table_tmplt || l_cr_lf  || l_cr_lf; 
 
        l_hist_view_seq_tmplt  := replace (l_hist_view_seq_tmplt,  '[PREFIX]', prefix_in); 
        l_hist_view_seq_tmplt  := replace (l_hist_view_seq_tmplt,  '[SCHEMA]', schema_in);   
        l_hist_view_seq_tmplt  := replace (l_hist_view_seq_tmplt, '[USER]', v('APP_USER')); 
        l_hist_view_seq_tmplt  := replace (l_hist_view_seq_tmplt, '[DATE]', SYSDATE);   
        l_hist_view_seq_tmplt  := replace (l_hist_view_seq_tmplt, '[APP_ID]', NV('APP_ID'));    
        l_hist_view_seq_tmplt  := replace (l_hist_view_seq_tmplt, '[FUNCTION]', utl_call_stack.subprogram (1) (1) || '.' || utl_call_stack.subprogram (1) (2));                   
        l_hist_table_DDL       := l_hist_table_DDL || l_hist_view_seq_tmplt || l_cr_lf; 
 
    --    l_hist_table_DDL       := REGEXP_REPLACE(l_hist_table_DDL, '[^[:print:]]', ''); -- removes '/' 
        l_hist_table_DDL       := l_hist_table_DDL;         
         
        l_RETURN_DDL := l_RETURN_DDL || l_hist_table_DDL;       
    else 
        debug_it ('  NO History Table created.'); 
    end if;  -- create_hist_table 
 
--  *** Build the AUDIT Trigger *** 
    if nvl(create_aud_trigger, 'N') = 'Y' 
    then 
        debug_it ('  Creating History Audit Trigger(s)'); 
 
        if schema_in is NULL 
        then raise_app_error (-20002, 'Invalid call to function, must provide SCHEMA when creating History TRIGGER.'); 
        end if; 
 
        if prefix_in is NULL  -- 06/10/24 S.Vicars added this check 
        then raise_app_error (-20004, 'Invalid call to function, must provide PREFIX when creating History TRIGGER.'); 
        end if; 
 
        if table_in is NULL 
        then raise_app_error (-20003, 'Invalid call to function, must provide TABLE when creating History TRIGGER.'); 
        end if;         
 
        load_data_type_abbr; 
         
        if data_type_abbr.FIRST is NULL 
        then raise_app_error (-20005, 'Fatal Error: Data Types not available. Contact APEX_Support.'); 
        end if; 
 
        l_aud_trgr_pt_1 := replace (l_aud_trgr_pt_1, '[SCHEMA]', schema_in); 
        l_aud_trgr_pt_1 := replace (l_aud_trgr_pt_1, '[TABLE]',  table_in);  
        l_aud_trgr_pt_1 := replace (l_aud_trgr_pt_1, '[USER]', v('APP_USER')); 
        l_aud_trgr_pt_1 := replace (l_aud_trgr_pt_1, '[DATE]', SYSDATE);   
        l_aud_trgr_pt_1 := replace (l_aud_trgr_pt_1, '[APP_ID]', NV('APP_ID'));  
        l_aud_trgr_pt_1 := replace (l_aud_trgr_pt_1, '[FUNCTION]', utl_call_stack.subprogram (1) (1) || '.' || utl_call_stack.subprogram (1) (2));           
 
        l_hist_aud_trgr_DDL := l_hist_aud_trgr_DDL || l_aud_trgr_pt_1 || l_cr_lf; 
         
        select  
            count(column_name) into l_column_count 
        from user_tab_cols --dba_tab_cols 
    --    where owner = upper(schema_in)  
    --          and table_name = upper(table_in); 
        where table_name = upper(table_in);               
 
        if l_column_count < 1 
        then raise_app_error (-20006, 'Error: No columns found for Schema='||schema_in||', Table='||table_in); 
        end if;                
 
        for crsr_columns in ( 
            select  
              --   owner 
              --  ,
                 table_name 
                ,column_name 
                ,data_type 
            from user_tab_cols --dba_tab_cols 
        --    where owner = upper(schema_in)  
        --      and table_name = upper(table_in)
            where table_name = upper(table_in)         
              and column_name NOT in (select column_value from table (pipelined_list (p_string => l_exclude_columns_lst, p_delimiter => ','))) 
            order by column_id 
        ) 
        loop 
            if crsr_columns.data_type = 'CLOB' 
            or crsr_columns.data_type = 'BLOB' 
            then 
                l_aud_trgr_work := l_aud_trgr_pt_6; -- don't change the original templates!  SPECIAL TEMPLATE FOR BLOB/CLOB 
            else 
                l_aud_trgr_work := l_aud_trgr_pt_2; -- don't change the original templates! 
            end if; 
         --   debug_it ('table='||crsr_columns.table_name||', column_name='||crsr_columns.column_name||', data_type='||crsr_columns.data_type||', Abbreviation='||data_type_abbr(crsr_columns.data_type)); 
    --        l_aud_trgr_work := l_aud_trgr_pt_2; -- don't change the original templates! 
            l_aud_trgr_work := replace (l_aud_trgr_work, '[SCHEMA]', schema_in); 
            l_aud_trgr_work := replace (l_aud_trgr_work, '[PREFIX]', prefix_in);             
            l_aud_trgr_work := replace (l_aud_trgr_work, '[COLUMN_NAME]', lower(crsr_columns.column_name)); 
            l_aud_trgr_work := replace (l_aud_trgr_work, '[PK]', table_pk_col_name_in); 
            l_aud_trgr_work := replace (l_aud_trgr_work, '[COLUMN_NAME_UC]', crsr_columns.column_name); 
            l_aud_trgr_work := replace (l_aud_trgr_work, '[DATA_TYPE_UC]', crsr_columns.data_type); 
            l_aud_trgr_work := replace (l_aud_trgr_work, '[DATA_TYPE_ABBR]', lower(data_type_abbr(crsr_columns.data_type)));  
            l_hist_aud_trgr_DDL := l_hist_aud_trgr_DDL || l_aud_trgr_work || l_cr_lf;                       
        end loop; 
 
        -- get the "middle part" - don't forget the l_cr_lf 
        l_hist_aud_trgr_DDL := l_hist_aud_trgr_DDL || l_aud_trgr_pt_3 || l_cr_lf; 
        
        -- do the "delete" part (part 4) - cursor loop, including l_cr_lf 
        for crsr_columns in ( 
            select  
              --   owner 
              --  ,
                 table_name 
                ,column_name 
                ,data_type 
            from user_tab_cols --dba_tab_cols 
            -- where clauses need to be exactly the same! 
            -- where owner = upper(schema_in)  
            --  and table_name = upper(table_in) 
            where table_name = upper(table_in)              
              and column_name NOT in (select column_value from table (pipelined_list (p_string => l_exclude_columns_lst, p_delimiter => ',')))   
            order by column_id                           
        ) 
        loop 
        --    debug_it ('table='||crsr_columns.table_name||', column_name='||crsr_columns.column_name||', data_type='||crsr_columns.data_type||', Abbreviation='||data_type_abbr(crsr_columns.data_type)); 
            l_aud_trgr_work := l_aud_trgr_pt_4; -- don't change the original templates! 
            l_aud_trgr_work := replace (l_aud_trgr_work, '[SCHEMA]', schema_in); 
            l_aud_trgr_work := replace (l_aud_trgr_work, '[PREFIX]', prefix_in); 
            l_aud_trgr_work := replace (l_aud_trgr_work, '[COLUMN_NAME]', lower(crsr_columns.column_name)); 
            l_aud_trgr_work := replace (l_aud_trgr_work, '[PK]', table_pk_col_name_in); 
            l_aud_trgr_work := replace (l_aud_trgr_work, '[COLUMN_NAME_UC]', crsr_columns.column_name); 
            l_aud_trgr_work := replace (l_aud_trgr_work, '[DATA_TYPE_UC]', crsr_columns.data_type); 
            l_aud_trgr_work := replace (l_aud_trgr_work, '[DATA_TYPE_ABBR]', lower(data_type_abbr(crsr_columns.data_type)));  
            l_hist_aud_trgr_DDL := l_hist_aud_trgr_DDL || l_aud_trgr_work || l_cr_lf;                       
        end loop; 
 
--        debug_it ('Trigger after 4th part='||l_hist_aud_trgr_DDL); 
         
        -- do the last section (part 5) 
        --l_aud_trgr_pt_5 := replace (l_aud_trgr_pt_5, '[PREFIX]', schema_in); 
        l_aud_trgr_pt_5 := replace (l_aud_trgr_pt_5, '[TABLE]',  table_in);          
        l_hist_aud_trgr_DDL := l_hist_aud_trgr_DDL || l_aud_trgr_pt_5 || l_cr_lf; 
         
        debug_it ('Trigger after 5th part='||l_hist_aud_trgr_DDL); 
 
       l_RETURN_DDL := l_RETURN_DDL || l_hist_aud_trgr_DDL;   
    else 
        debug_it ('  NO Tiggers created.'); 
    end if;  -- create_aud_trigger 
 
    debug_it ('*** Ending GEN_HIST_AUD_TRIGGER ***'); 
 
    RETURN l_RETURN_DDL; 

end GEN_HIST_AUD_TRIGGER;

end APXSHR_HIST_PKG;
/ 