begin
    --APXSHR_LOV_DETAILS: 10/10000 rows exported, APEX$DATA$PKG/APXSHR_LOV_DETAILS$61918
    apex_data_install.load_supporting_object_data(p_table_name => 'APXSHR_LOV_DETAILS', p_delete_after_install => true );
end;