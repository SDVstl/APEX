begin
    --APXSHR_PGM_OPTIONS: 11/10000 rows exported, APEX$DATA$PKG/APXSHR_PGM_OPTIONS$370288
    apex_data_install.load_supporting_object_data(p_table_name => 'APXSHR_PGM_OPTIONS', p_delete_after_install => false );
end;