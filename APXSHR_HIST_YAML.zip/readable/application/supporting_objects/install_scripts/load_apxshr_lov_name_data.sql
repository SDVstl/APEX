begin
    --APXSHR_LOV_NAME: 1/10000 rows exported, APEX$DATA$PKG/APXSHR_LOV_NAME$975458
    apex_data_install.load_supporting_object_data(p_table_name => 'APXSHR_LOV_NAME', p_delete_after_install => true );
end;