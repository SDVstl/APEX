create or replace PACKAGE  "APXSHR_PGM_OPTS" as           
/****************************************************************************   
* This package is used to return variables to APEX applications that control*   
* execution.  It is especially handy for 'parameter' type information that  *   
* might control execution.  It reduces the need for custom parameter or     *   
* option tables.  For example, you may set a "Test Mode" variable that      *   
* controls whether emails get sent to actual recipients or to a test address*   
* during app testing.                                                       *   
****************************************************************************/ 
/*  Modification Log 
    Date        Who             Change 
    June 2024   S.Vicars        Change Log Created. 
    06/24/24    S.Vicars        Added new "default" function to return CLOB 
                                without passing in any argument for pgm_opt_typ. 
                                This makes it much easier to return a CLOB when using
                                a 'Dynamic Content' Source.  You can just do something
                                like this:

                                return APXSHR_PGM_OPTS.rtn_pgm_opt (app_alias_in => :APP_ALIAS, opt_no_in => to_number(:APP_PAGE_ID) + 100);

                                Otherwise, you'd have to build an anonymous block and DECLARE a CLOB so you could pass it.  MUCH easier this way.
 
                                Added procedure BUILD_COLL_FROM_REST to construct 
                                collections for the PGMOPTs application.                                 
*/      
  FUNCTION  rtn_pgm_opt (app_id_in    IN NUMBER,   opt_no_in IN NUMBER, pgm_opt_typ IN VARCHAR2)  RETURN VARCHAR;    -- App ID in, RETURN VARCHAR    
  FUNCTION  rtn_pgm_opt (app_id_in    IN NUMBER,   opt_no_in IN NUMBER, pgm_opt_typ IN BOOLEAN)   RETURN BOOLEAN;    -- App ID in, RETURN BOOLEAN    
  FUNCTION  rtn_pgm_opt (app_id_in    IN NUMBER,   opt_no_in IN NUMBER, pgm_opt_typ IN NUMBER)    RETURN NUMBER;     -- App ID in, RETURN NUMBER    
  FUNCTION  rtn_pgm_opt (app_id_in    IN NUMBER,   opt_no_in IN NUMBER, pgm_opt_typ IN DATE)      RETURN DATE;       -- App ID in, RETURN DATE    
  FUNCTION  rtn_pgm_opt (app_id_in    IN NUMBER,   opt_no_in IN NUMBER, pgm_opt_typ IN TIMESTAMP) RETURN TIMESTAMP;  -- App ID in, RETURN DATE    
  FUNCTION  rtn_pgm_opt (app_id_in    IN NUMBER,   opt_no_in IN NUMBER, pgm_opt_typ IN CLOB)      RETURN CLOB;       -- App ID in, RETURN CLOB  
  FUNCTION  rtn_pgm_opt (app_id_in    IN NUMBER,   opt_no_in IN NUMBER)                           RETURN CLOB;       -- App ID in, RETURN CLOB     
  FUNCTION  rtn_pgm_opt (app_id_in    IN NUMBER,   opt_no_in IN NUMBER, pgm_opt_typ IN BLOB)      RETURN BLOB;       -- App ID in, RETURN BLOB    
         
  FUNCTION  rtn_pgm_opt (app_alias_in IN VARCHAR2, opt_no_in IN NUMBER, pgm_opt_typ IN VARCHAR2)  RETURN VARCHAR;    -- App ALIAS in, RETURN VARCHAR    
  FUNCTION  rtn_pgm_opt (app_alias_in IN VARCHAR2, opt_no_in IN NUMBER, pgm_opt_typ IN BOOLEAN)   RETURN BOOLEAN;    -- App ALIAS in, RETURN BOOLEAN   
  FUNCTION  rtn_pgm_opt (app_alias_in IN VARCHAR2, opt_no_in IN NUMBER, pgm_opt_typ IN NUMBER)    RETURN NUMBER;     -- App ALIAS in, RETURN NUMBER   
  
  FUNCTION  rtn_pgm_opt (app_alias_in IN VARCHAR2, opt_no_in IN NUMBER, pgm_opt_typ IN DATE)      RETURN DATE;       -- App ALIAS in, RETURN DATE     
  FUNCTION  rtn_pgm_opt (app_alias_in IN VARCHAR2, opt_no_in IN NUMBER, pgm_opt_typ IN TIMESTAMP) RETURN TIMESTAMP;  -- App ALIAS in, RETURN TIMESTAMP   
  FUNCTION  rtn_pgm_opt (app_alias_in IN VARCHAR2, opt_no_in IN NUMBER, pgm_opt_typ IN CLOB)      RETURN CLOB;       -- App ALIAS in, RETURN CLOB   
  FUNCTION  rtn_pgm_opt (app_alias_in IN VARCHAR2, opt_no_in IN NUMBER)                           RETURN CLOB;       -- App ALIAS in, RETURN CLOB    
  FUNCTION  rtn_pgm_opt (app_alias_in IN VARCHAR2, opt_no_in IN NUMBER, pgm_opt_typ IN BLOB)      RETURN BLOB;       -- App ALIAS in, RETURN CLOB   
     
  function pgm_opt_exists (app_alias_in IN VARCHAR2, opt_no_in IN NUMBER)   RETURN BOOLEAN;   -- App ALIAS in, RETURN BOOLEAN   
  function pgm_opt_exists (app_id_in    IN NUMBER,   opt_no_in IN NUMBER)   RETURN BOOLEAN;   -- App ID in,    RETURN BOOLEAN   
    
  function pgm_opt_exists_text (app_alias_in IN VARCHAR2, opt_no_in IN NUMBER, text_in in VARCHAR)   RETURN VARCHAR;  -- WRAPPER FOR PREVIOUS FUNCTIONS THAT RETURNS TEXT INSTEAD OF BOOLEAN (for use in SQL)   
  function pgm_opt_exists_text (app_id_in    IN NUMBER,   opt_no_in IN NUMBER, text_in in VARCHAR)   RETURN VARCHAR;  -- WRAPPER FOR PREVIOUS FUNCTIONS THAT RETURNS TEXT INSTEAD OF BOOLEAN (for use in SQL)   
     
  procedure get_options (app_id_in    IN NUMBER,   opt_no_in IN NUMBER, pgm_options OUT APXSHR_PGM_OPTIONS%ROWTYPE);   -- DEPRECATED - do not use.   
  procedure get_options (app_alias_in IN VARCHAR2, opt_no_in IN NUMBER, pgm_options OUT APXSHR_PGM_OPTIONS%ROWTYPE);   -- DEPRECATED - do not use.  
 
/* 
    BUILD_COLL_FROM_REST builds an APEX COLLECTION for the PGMOPT app. 
    opt_alias_in = ALIAS to look up in the PGMOPTS table 
    environment_in = LOCAL or REMOTE.  Determines which REST Data Source to read. 
    coll_name_in = The Collection Name to build & populate. 
*/ 
  procedure BUILD_COLL_FROM_REST ( opt_alias_in   in varchar2,  
                                   environment_in in varchar2,  
                                   coll_name_in   in varchar2,
                                   port_in        in varchar2 DEFAULT 'STAGING' );  
     
end APXSHR_PGM_OPTS;
/
create or replace PACKAGE BODY  "APXSHR_PGM_OPTS" AS   
/*  Modification Log 
    Date        Who             Change 
    June 2024   S.Vicars        Change Log Created. 
    06/24/24    S.Vicars        Added new "default" function to return CLOB 
                                without passing in any argument for pgm_opt_typ. 
 
                                Added procedure BUILD_COLL_FROM_REST to construct 
                                collections for the PGMOPTs application.    
 
    07/01/24    S.Vicars        Added effective date logic to get_options functions.      
    04/14/25    S.Vicars        TPW-12997.  Modified get_options procecedures to allow more  
                                consistent behavior and to prevent a 'ORA-01422 exact  
                                fetch returns more than requested number of rows' error 
                                when a PGMOPTS user enters 2 or more rows with same 
                                ALIAS & OPTION #.  Usually by having a row with the APP ID 
                                null and another with the APP ID present. 
*/        
  g_pgm_rec APXSHR_PGM_OPTIONS%ROWTYPE;  -- GLOBAL record used by all   
  g_lit_notfound VARCHAR2(100) := 'Program Option Not Found for App#:';   
  g_lit_toomanyfound VARCHAR2(100) := 'More than ONE (duplicate) Program Option Found for App#:';  -- 04/14/25 S.Vicars TPW-12997 
     
/***** FUNCTIONS FOLLOW ******/   
   
-- overloading these FUNCTIONS to make calling easier     
   
/***********************************************************   
* Function: rtn_pgm_opt (OVERLOADED)                       *   
* Author: Scott Vicars                                     *   
* Purpose: Return a variable (depends on which over-loaded *   
*          version of function executed) to calling app.   *   
*          Pass either APP_ALIAS (varchar) or APP_ID       *   
*          (number) - whichever makes sense for you.       *   
*          The "type" of variable in pgm_opt_typ determines*   
*          what type of value is returned.                 *   
***********************************************************/   
function rtn_pgm_opt (app_id_in    in NUMBER,   opt_no_in in number, pgm_opt_typ in varchar2) return varchar is     
begin   
     
  get_options (app_id_in, opt_no_in, g_pgm_rec);   
  RETURN g_pgm_rec.opt_val_varchar;   
     
end rtn_pgm_opt;   
   
function rtn_pgm_opt (app_id_in    in NUMBER,   opt_no_in in number, pgm_opt_typ in boolean) return boolean is   -- App ID in, BOOLEAN out      
begin   
  get_options (app_id_in, opt_no_in, g_pgm_rec);   
     
  if g_pgm_rec.opt_val_boolean = 'TRUE'   
  then RETURN TRUE;   
  else RETURN FALSE;   
  end if;   
end rtn_pgm_opt;   
    
function rtn_pgm_opt (app_id_in    in NUMBER,   opt_no_in in number, pgm_opt_typ IN number) return number is    -- App ID in, NUMBER out     
begin   
  get_options (app_id_in, opt_no_in, g_pgm_rec);   
  RETURN g_pgm_rec.opt_val_number;   
end rtn_pgm_opt;    
   
function rtn_pgm_opt (app_id_in    in NUMBER,   opt_no_in in number, pgm_opt_typ IN DATE) return DATE is    -- App ID in, DATE out     
begin   
  get_options (app_id_in, opt_no_in, g_pgm_rec);   
  RETURN g_pgm_rec.opt_val_date;   
end rtn_pgm_opt;   
   
function rtn_pgm_opt (app_alias_in in VARCHAR2, opt_no_in in number, pgm_opt_typ IN DATE) return DATE is    -- App ALIAS in, DATE out     
begin   
  get_options (app_alias_in, opt_no_in, g_pgm_rec);   
  RETURN g_pgm_rec.opt_val_date;   
end rtn_pgm_opt;   
   
function rtn_pgm_opt (app_id_in    in NUMBER,   opt_no_in in number, pgm_opt_typ IN TIMESTAMP) return TIMESTAMP is    -- App ID in, TIMESTAMP out     
begin   
  get_options (app_id_in, opt_no_in, g_pgm_rec);   
  RETURN g_pgm_rec.opt_val_timestamp;   
end rtn_pgm_opt;   
   
function rtn_pgm_opt (app_id_in    in NUMBER,   opt_no_in in number, pgm_opt_typ IN CLOB) return CLOB is    -- App ID in, CLOB out     
begin   
  get_options (app_id_in, opt_no_in, g_pgm_rec);   
  RETURN g_pgm_rec.opt_val_clob;   
end rtn_pgm_opt;   
 
function rtn_pgm_opt (app_id_in    IN NUMBER,   opt_no_in IN NUMBER) return CLOB is    -- App ID in, NO pgm_opt_typ, CLOB out    
begin   
  get_options (app_id_in, opt_no_in, g_pgm_rec);   
  RETURN g_pgm_rec.opt_val_clob;   
end rtn_pgm_opt;   
   
function rtn_pgm_opt (app_id_in    in NUMBER,   opt_no_in in number, pgm_opt_typ IN BLOB) return BLOB is    -- App ID in, BLOB out     
begin   
  get_options (app_id_in, opt_no_in, g_pgm_rec);   
  RETURN g_pgm_rec.opt_val_img;   
end rtn_pgm_opt;   
     
function rtn_pgm_opt (app_alias_in in VARCHAR2, opt_no_in in number, pgm_opt_typ IN TIMESTAMP) return TIMESTAMP is    -- App ALIAS in, TIMESTAMP out     
begin   
  get_options (app_alias_in, opt_no_in, g_pgm_rec);   
  RETURN g_pgm_rec.opt_val_timestamp;   
end rtn_pgm_opt;   
   
function rtn_pgm_opt (app_alias_in in VARCHAR2, opt_no_in in number, pgm_opt_typ IN CLOB) return CLOB is    -- App ALIAS in, CLOB out     
begin   
  get_options (app_alias_in, opt_no_in, g_pgm_rec);   
  RETURN g_pgm_rec.opt_val_clob;   
end rtn_pgm_opt;   
 
function rtn_pgm_opt (app_alias_in in VARCHAR2, opt_no_in in number) return CLOB is    -- App ALIAS in, NO pgm_opt_typ, CLOB out     
begin   
  get_options (app_alias_in, opt_no_in, g_pgm_rec);   
  RETURN g_pgm_rec.opt_val_clob;   
end rtn_pgm_opt;  
     
function rtn_pgm_opt (app_alias_in in VARCHAR2, opt_no_in in number, pgm_opt_typ IN BLOB) return BLOB is    -- App ALIAS in, BLOB out     
begin   
  get_options (app_alias_in, opt_no_in, g_pgm_rec);   
  RETURN g_pgm_rec.opt_val_img;   
end rtn_pgm_opt;   
   
function rtn_pgm_opt (app_alias_in in VARCHAR2, opt_no_in in number, pgm_opt_typ in varchar2) return varchar is  -- App ALIAS in, VARCHAR out   
begin    
  get_options (app_alias_in, opt_no_in, g_pgm_rec);   
  RETURN g_pgm_rec.opt_val_varchar;   
     
end rtn_pgm_opt;   
   
function rtn_pgm_opt (app_alias_in in VARCHAR2, opt_no_in in number, pgm_opt_typ in boolean) return boolean is   -- App ID in, BOOLEAN out      
begin   
  get_options (app_alias_in, opt_no_in, g_pgm_rec);   
     
  if g_pgm_rec.opt_val_boolean = 'TRUE'   
  then RETURN TRUE;   
  else RETURN FALSE;   
  end if;   
end rtn_pgm_opt;   
   
function rtn_pgm_opt (app_alias_in in VARCHAR2, opt_no_in in number, pgm_opt_typ IN number) return number is    -- App ID in, NUMBER out     
begin   
  get_options (app_alias_in, opt_no_in, g_pgm_rec);   
  RETURN g_pgm_rec.opt_val_number;   
end rtn_pgm_opt;   
   
-- overloading these FUNCTIONS to make calling easier   
/***********************************************************   
* Function: pgm_opt_exists_text (OVERLOADED)               *   
* Author: Scott Vicars                                     *   
* Purpose: Return a VARCHAR ('TRUE' or 'FALSE') to app or  *   
*          SQL.  SQL cannot handle a BOOLEAN.  This wrapper*   
*          calls the pgm_opt_exists function, and trans-   *   
*          lates the BOOLEAN to VARCHAR.                   *   
***********************************************************/   
function pgm_opt_exists_text (app_alias_in IN VARCHAR2, opt_no_in IN NUMBER, text_in in VARCHAR)   RETURN VARCHAR is   
begin   
   
  if pgm_opt_exists (app_alias_in, opt_no_in)   
  then RETURN 'TRUE';   
  else RETURN 'FALSE';   
  end if;   
     
end pgm_opt_exists_text;   
   
function pgm_opt_exists_text (app_id_in    IN NUMBER,   opt_no_in IN NUMBER, text_in in VARCHAR)   RETURN VARCHAR is   
begin   
   
  if pgm_opt_exists (app_id_in, opt_no_in)   
  then RETURN 'TRUE';   
  else RETURN 'FALSE';   
  end if;   
     
end pgm_opt_exists_text;   
   
-- overloading these FUNCTIONS to make calling easier   
/***********************************************************   
* Function: pgm_opt_exists (OVERLOADED)                    *   
* Author: Scott Vicars                                     *   
* Purpose: Return a BOOLEAN to app, based on whether a     *   
*          row exists on the APXSHR_PGM_OPTIONS table for  *   
*          the specified APP_ID/ALIAS and Option #.        *   
***********************************************************/   
function pgm_opt_exists (app_alias_in IN VARCHAR2, opt_no_in IN NUMBER)   RETURN BOOLEAN is   
begin   
  get_options (app_alias_in, opt_no_in, g_pgm_rec);   
     
  if g_pgm_rec.opt_val_varchar LIKE g_lit_notfound||'%'   
  then RETURN FALSE;   
  else RETURN TRUE;   
  end if;   
     
end pgm_opt_exists;   
   
function pgm_opt_exists (app_id_in    IN NUMBER,   opt_no_in IN NUMBER)   RETURN BOOLEAN is   
begin   
   
  get_options (app_id_in, opt_no_in, g_pgm_rec);   
     
  if g_pgm_rec.opt_val_varchar LIKE g_lit_notfound||'%'   
  then RETURN FALSE;   
  else RETURN TRUE;   
  end if;   
     
end pgm_opt_exists;   
   
/*** PROCEDURES FOLLOW ****************************************************/   
-- Overloaded procedure to retrieve PGM_OPTIONS by APP ID    
procedure get_options (app_id_in IN NUMBER, opt_no_in IN NUMBER,     
                       pgm_options out APXSHR_PGM_OPTIONS%ROWTYPE ) is   
begin   
       
  begin   
    
    select *   
    into  pgm_options   
    from apxshr_pgm_options   
    where APP_ID = app_id_in    
      and OPT_NO = opt_no_in 
      -- 07/01/24 S.Vicars adding effective date logic to PGMOPTs 
      -- the "nvl" code allows for NULL effective dates always returning 
      and SYSDATE between nvl(EFF_START_DA, SYSDATE - 1) and nvl(EFF_END_DA, SYSDATE + 1);    
 
    exception  
        when NO_DATA_FOUND then    
          pgm_options.opt_val_varchar := g_lit_notfound||app_id_in||', Opt#:'||opt_no_in||'!';  
          pgm_options.opt_val_clob    := g_lit_notfound||app_id_in||', Opt#:'||opt_no_in||'!';  -- 4/14/25 S.Vicars more consistent 
          pgm_options.opt_val_number  := NULL;   
          pgm_options.opt_val_boolean := NULL;   
 
        -- 4/14/25. S.Vicars TPW-12997: added for more consistent behavior and to prevent a 'ORA-01422 exact fetch returns more than requested number of rows' error  
        when TOO_MANY_ROWS then    
          pgm_options.opt_val_varchar := g_lit_toomanyfound||app_id_in||', Opt#:'||opt_no_in||'!'; 
          pgm_options.opt_val_clob    := g_lit_toomanyfound||app_id_in||', Opt#:'||opt_no_in||'!';   
          pgm_options.opt_val_number  := NULL;   
          pgm_options.opt_val_boolean := NULL;         
  end; -- select block   
    
end get_options;   
   
-- Overloaded procedure to retrieve PGM_OPTIONS by APP ALIAS     
procedure get_options (app_alias_in IN VARCHAR2, opt_no_in IN NUMBER,     
                       pgm_options out APXSHR_PGM_OPTIONS%ROWTYPE ) is   
begin   
       
  begin   
    select *   
    into pgm_options   
    from apxshr_pgm_options   
    where APP_ALIAS = app_alias_in    
      and OPT_NO    = opt_no_in 
      -- 07/01/24 S.Vicars adding effective date logic to PGMOPTs 
      -- the "nvl" code allows for NULL effective dates always returning 
      and SYSDATE between nvl(EFF_START_DA, SYSDATE - 1) and nvl(EFF_END_DA, SYSDATE + 1);   
 
    exception  
        when NO_DATA_FOUND then    
          pgm_options.opt_val_varchar := g_lit_notfound||app_alias_in||'", Opt#:'||opt_no_in||'!';   
          pgm_options.opt_val_clob    := g_lit_notfound||app_alias_in||'", Opt#:'||opt_no_in||'!';  -- 4/14/25 S.Vicars more consistent 
          pgm_options.opt_val_number  := NULL;   
          pgm_options.opt_val_boolean := NULL;  
 
        -- 4/14/25. S.Vicars TPW-12997:  added for more consistent behavior and to prevent a 'ORA-01422 exact fetch returns more than requested number of rows' error            
        when TOO_MANY_ROWS then    
          pgm_options.opt_val_varchar := g_lit_toomanyfound||app_alias_in||', Opt#:'||opt_no_in||'!';  
          pgm_options.opt_val_clob    := g_lit_toomanyfound||app_alias_in||', Opt#:'||opt_no_in||'!';   
          pgm_options.opt_val_number  := NULL;   
          pgm_options.opt_val_boolean := NULL;          
  end; -- select block   
       
end get_options;   
 
procedure BUILD_COLL_FROM_REST ( opt_alias_in   in varchar2,  
                                 environment_in in varchar2,  
                                 coll_name_in   in varchar2,
                                 port_in        in varchar2 DEFAULT 'STAGING' ) is 
    l_context       apex_exec.t_context; 
    l_filters       apex_exec.t_filters; 
    l_columns       apex_exec.t_columns; 
 
    l_row           pls_integer := 1; 
 
-- indexes for JSON object data columns (i.e., where to find each column) 
    l_id_idx                pls_integer; 
    l_app_id_idx            pls_integer; 
    l_opt_no_idx            pls_integer; 
    l_opt_name_idx          pls_integer; 
    l_app_alias_idx         pls_integer; 
    l_opt_val_clob_idx      pls_integer; 
    l_opt_val_date_idx      pls_integer;   
    l_opt_val_number_idx    pls_integer; 
    l_opt_val_boolean_idx   pls_integer; 
    l_opt_val_varchar_idx   pls_integer; 
    l_opt_val_timestamp_idx pls_integer; 
    l_opt_val_img_idx       pls_integer; 
    l_img_mime_type_idx     pls_integer; 
    l_img_file_name_idx     pls_integer; 
    l_img_char_set_idx      pls_integer;   
    l_img_last_upd_da_idx   pls_integer;  
    l_cre_ut_idx            pls_integer; 
    l_cre_uid_cd_idx        pls_integer; 
    l_revsn_ut_idx          pls_integer; 
    l_revsn_uid_cd_idx      pls_integer;   
    l_eff_start_da_idx      pls_integer; 
    l_eff_end_da_idx        pls_integer;     
 
    l_params        apex_exec.t_parameters; 
 
    -- the static ID of the REST Data Sources used in this procedure 
    l_static_id_STG APXSHR_PGM_OPTIONS.OPT_VAL_VARCHAR%TYPE := APXSHR_PGM_OPTS.rtn_pgm_opt ('PGMOPT', 6, 'text'); 
    l_static_id_PRD APXSHR_PGM_OPTIONS.OPT_VAL_VARCHAR%TYPE := APXSHR_PGM_OPTS.rtn_pgm_opt ('PGMOPT', 5, 'text');    
    l_static_id     APXSHR_PGM_OPTIONS.OPT_VAL_VARCHAR%TYPE := NULL; 
 
BEGIN 
    apex_debug.info('*** Starting: BUILD_COLL_FROM_REST. opt_alias_in=%s, environment_in=%s, coll_name_in=%s, port_in=%s', opt_alias_in, environment_in, coll_name_in, port_in);
    -- error handling 
    if opt_alias_in is NULL 
    then 
        raise_application_error (-20000, 'Argument: opt_alias_in required for BUILD_COLL_FROM_REST!'); 
    end if; 
 
    if environment_in is NULL 
    then 
        raise_application_error (-20001, 'Argument: environment_in required for BUILD_COLL_FROM_REST!'); 
    end if;    
 
    if environment_in NOT in ('LOCAL','REMOTE') 
    then 
        raise_application_error (-20002, 'Argument: environment_in MUST be "LOCAL" or "REMOTE" for BUILD_COLL_FROM_REST!'); 
    end if;      
 
    if coll_name_in is NULL 
    then 
        raise_application_error (-20003, 'Argument: coll_name_in required for BUILD_COLL_FROM_REST!'); 
    end if;     
 
    -- determine which REST Source to use based on environment (PRD or STG) 
    if port_in = 'STAGING' -- APXSHR_PACKAGE.staging_port 
    then 
        apex_debug.info('port_in = STAGING');
        if environment_in = 'LOCAL' 
        then 
            apex_debug.info('environment_in = LOCAL');
            l_static_id := l_static_id_STG; 
        else 
            apex_debug.info('(else) environment_in = %s',environment_in);
            l_static_id := l_static_id_PRD; 
        end if; 
    elsif port_in = 'PRODUCTION' -- APXSHR_PACKAGE.production_port 
    then 
        apex_debug.info('port_in = PRODUCTION');
        if environment_in = 'LOCAL' 
        then  
            apex_debug.info('environment_in = LOCAL');
            l_static_id := l_static_id_PRD; 
        else 
            apex_debug.info('(else) environment_in = %s',environment_in);
            l_static_id := l_static_id_STG; 
        end if; 
    else 
        apex_debug.info('(else) port_in = %s',port_in);
        l_static_id := l_static_id_STG;        
    end if; 

    apex_debug.info('l_static_id=%s',l_static_id);
 
    --  add the parameter passed with the call to the REST Data Source 
    apex_exec.add_parameter( l_params, 'my_alias', nvl(opt_alias_in, 'TEST') );  -- parameter my_alias not to be confused column app_alias. CaSe SeNsiTiVe!!! 
 
    apex_debug.info( '* Before: apex_exec.open_rest_source_query' ); 
 
    --  execute the query for the REST Data Source 
    l_context := apex_exec.open_rest_source_query ( 
        p_static_id     => l_static_id,   -- see REST Data Sources in Shared Components of app.  
        p_parameters    => l_params,         
        p_max_rows      => 1000 ); 
 
    apex_debug.info( '* AFTER: apex_exec.open_rest_source_query' );         
 
    --  now that we have the JSON results, map the columns to their respective indexes 
    l_id_idx                := apex_exec.get_column_position( l_context, 'ID' ); 
    l_app_id_idx            := apex_exec.get_column_position( l_context, 'APP_ID' );     
    l_opt_no_idx            := apex_exec.get_column_position( l_context, 'OPT_NO' ); 
    l_opt_name_idx          := apex_exec.get_column_position( l_context, 'OPT_NAME' );     
    l_app_alias_idx         := apex_exec.get_column_position( l_context, 'APP_ALIAS' ); 
    l_opt_val_clob_idx      := apex_exec.get_column_position( l_context, 'OPT_VAL_CLOB' ); 
    l_opt_val_date_idx      := apex_exec.get_column_position( l_context, 'OPT_VAL_DATE' );   
    l_opt_val_number_idx    := apex_exec.get_column_position( l_context, 'OPT_VAL_NUMBER' ); 
    l_opt_val_boolean_idx   := apex_exec.get_column_position( l_context, 'OPT_VAL_BOOLEAN' ); 
    l_opt_val_varchar_idx   := apex_exec.get_column_position( l_context, 'OPT_VAL_VARCHAR' ); 
    l_opt_val_timestamp_idx := apex_exec.get_column_position( l_context, 'OPT_VAL_TIMESTAMP' );     
     
    l_opt_val_img_idx       := apex_exec.get_column_position( l_context, 'OPT_VAL_IMG' ); 
     
    l_img_mime_type_idx     := apex_exec.get_column_position( l_context, 'IMG_MIME_TYPE' ); 
    l_img_file_name_idx     := apex_exec.get_column_position( l_context, 'IMG_FILE_NAME' ); 
    l_img_char_set_idx      := apex_exec.get_column_position( l_context, 'IMG_CHAR_SET' );   
    l_img_last_upd_da_idx   := apex_exec.get_column_position( l_context, 'IMG_LAST_UPD_DA' );   
 
    l_cre_ut_idx            := apex_exec.get_column_position( l_context, 'CRE_UT' );   
    l_cre_uid_cd_idx        := apex_exec.get_column_position( l_context, 'CRE_UID_CD' ); 
    l_revsn_ut_idx          := apex_exec.get_column_position( l_context, 'REVSN_UT' );   
    l_revsn_uid_cd_idx      := apex_exec.get_column_position( l_context, 'REVSN_UID_CD' ); 
 
    l_eff_start_da_idx      := apex_exec.get_column_position( l_context, 'EFF_START_DA' ); 
    l_eff_end_da_idx        := apex_exec.get_column_position( l_context, 'EFF_END_DA' );     
 
    apex_debug.info( '* AFTER: setting indexes, about to create Collection. ' );        
 
--  create collection for parsed results 
    apex_collection.create_or_truncate_collection( coll_name_in ); 

   -- apex_debug.info('apex_exec.get_varchar2 ( l_context, l_opt_val_timestamp_idx ) = %s', apex_exec.get_varchar2 ( l_context, l_opt_val_timestamp_idx ) );
 
    while apex_exec.next_row( l_context )  -- get the next row of the SQL results 
    LOOP 
        apex_debug.info( 'ID (char):   ' || apex_exec.get_varchar2( l_context, l_id_idx  ) ); 
        apex_debug.info( 'ID (num):    ' || apex_exec.get_varchar2( l_context, l_id_idx  ) ); 
         
        apex_collection.add_member ( 
             p_collection_name => coll_name_in 
            ,p_n001    => apex_exec.get_number    ( l_context, l_id_idx  )               -- id (PK of row) 
            ,p_n002    => apex_exec.get_varchar2  ( l_context, l_app_id_idx )            -- app_id 
            ,p_c001    => apex_exec.get_varchar2  ( l_context, l_app_alias_idx )         -- alias 
            ,p_n003    => apex_exec.get_number    ( l_context, l_opt_no_idx )            -- opt_no 
            ,p_c002    => apex_exec.get_varchar2  ( l_context, l_opt_name_idx )          -- opt_name  
            ,p_c003    => apex_exec.get_varchar2  ( l_context, l_opt_val_varchar_idx )   -- opt_val_varchar   
            ,p_n004    => apex_exec.get_number    ( l_context, l_opt_val_number_idx )    -- opt_val_number 
            ,p_c004    => apex_exec.get_varchar2  ( l_context, l_opt_val_boolean_idx )   -- opt_val_boolean 
            ,p_c005    => apex_exec.get_varchar2  ( l_context, l_opt_val_date_idx )      -- opt_val_date (raw) 
--            ,p_d001    => to_date( apex_exec.get_varchar2( l_context, l_opt_val_date_idx ), 'YYYY-MM-DD HH24:MI:SS' ) -- opt_val_date (as date) 
            ,p_d001    => to_date( apex_exec.get_varchar2( l_context, l_opt_val_date_idx ), 'YYYY-MM-DD"T"HH24:MI:SS"Z"' ) 
    --        ,p_c006    => to_char(apex_exec.get_timestamp ( l_context, l_opt_val_timestamp_idx ),'YYYY-MM-DD HH24:MI:SS.FF') -- opt_val_timestamp (raw) 
            ,p_c006    => apex_exec.get_varchar2 ( l_context, l_opt_val_timestamp_idx )             
            ,p_clob001 => apex_exec.get_clob      ( l_context, l_opt_val_clob_idx )      -- opt_val_clob  
 -- Per the documentation, BLOBS have to be converted to Base64 CLOBs for transport.  See the Resource definition in RESTful Services            
            ,p_blob001 => APEX_WEB_SERVICE.CLOBBASE642BLOB ( p_clob => apex_exec.get_clob ( l_context, l_opt_val_img_idx ))  -- opt_val_img (blob)  REST Service returns CLOB     
            ,p_c007    => apex_exec.get_varchar2  ( l_context, l_img_mime_type_idx )     -- img_mime_type            
            ,p_c008    => apex_exec.get_varchar2  ( l_context, l_img_file_name_idx )     -- img_file_name   
            ,p_c009    => apex_exec.get_varchar2  ( l_context, l_img_char_set_idx )      -- img_char_set  
            ,p_c010    => apex_exec.get_varchar2  ( l_context, l_img_last_upd_da_idx )      -- img_last_upd_da (raw)                           
  --          ,p_d002    => to_date (apex_exec.get_varchar2 ( l_context, l_img_last_upd_da_idx ), 'YYYY-MM-DD HH24:MI:SS')   -- img_last_upd_da (as date)      
            ,p_d002    => to_date (apex_exec.get_varchar2 ( l_context, l_img_last_upd_da_idx ), 'YYYY-MM-DD"T"HH24:MI:SS"Z"')                      
            ,p_c011    => apex_exec.get_varchar2  ( l_context, l_cre_ut_idx )      -- cre_ut (raw) 
 --           ,p_d003    => to_date( apex_exec.get_varchar2( l_context, l_cre_ut_idx ), 'YYYY-MM-DD HH24:MI:SS' ) -- cre_ut (as date)    2025-08-15T10:43:35Z
            ,p_d003    => to_date( apex_exec.get_varchar2( l_context, l_cre_ut_idx ), 'YYYY-MM-DD"T"HH24:MI:SS"Z"' )
            ,p_c012    => apex_exec.get_varchar2  ( l_context, l_cre_uid_cd_idx )      -- cre_uid_cd       
            ,p_c013    => apex_exec.get_varchar2  ( l_context, l_revsn_ut_idx )      -- revsn_ut (raw) 
 --           ,p_d004    => to_date( apex_exec.get_varchar2( l_context, l_revsn_ut_idx ), 'YYYY-MM-DD HH24:MI:SS' ) -- revsn_ut (as date)   
            ,p_d004    => to_date( apex_exec.get_varchar2( l_context, l_revsn_ut_idx ), 'YYYY-MM-DD"T"HH24:MI:SS"Z"'  ) 
            ,p_c014    => apex_exec.get_varchar2  ( l_context, l_revsn_uid_cd_idx )      -- revsn_uid_cd       
            ,p_d005    => to_date( apex_exec.get_varchar2( l_context, l_eff_start_da_idx ), 'YYYY-MM-DD"T"HH24:MI:SS"Z"' ) -- eff_start_da (as date)   
            ,p_c015    => apex_exec.get_varchar2  ( l_context, l_eff_end_da_idx ) -- eff_end_da (raw) - !!! will have to be formatted later - only 5 dates in collection !!!     
                                                                    
        ); 
 
    END LOOP; 
 
    apex_exec.close( l_context ); 
 /*
    EXCEPTION when others  
    then 
        apex_exec.close( l_context ); 
        RAISE; 
*/ 
end BUILD_COLL_FROM_REST; 
   
END APXSHR_PGM_OPTS;
/ 