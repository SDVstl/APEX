-- SEED DATA
begin
    begin
        INSERT INTO APXSHR_LOV_NAME (ID,APP_ALIAS,LOV_NA,LOV_DESC,SORT_ORDER_NO,ACTIVE_IND,CREATED,CREATED_BY,UPDATED,UPDATED_BY,GLOBAL_LOV_IND,ALLOW_USER_DELETE_IND) VALUES (NULL,'@APXSHR_GLOBAL_LOVS','Global Test Domain','Demonstration',10,'Y',to_date('25/06/2025 03:03:07', 'dd/mm/rrrr hh:mi:ss'),'nobody',to_date('25/06/2025 03:03:07', 'dd/mm/rrrr hh:mi:ss'),'nobody','Y','N');

        exception when DUP_VAL_ON_INDEX then NULL;
    end;

    begin
        INSERT INTO APXSHR_LOV_NAME (ID,APP_ALIAS,LOV_NA,LOV_DESC,SORT_ORDER_NO,ACTIVE_IND,CREATED,CREATED_BY,UPDATED,UPDATED_BY,GLOBAL_LOV_IND,ALLOW_USER_DELETE_IND) VALUES (NULL,'TEST','Test Domain','Demonstration',10,'Y',to_date('25/06/2025 03:03:07', 'dd/mm/rrrr hh:mi:ss'),'nobody',to_date('25/06/2025 03:03:07', 'dd/mm/rrrr hh:mi:ss'),'nobody','N','Y');

        exception when DUP_VAL_ON_INDEX then NULL;
    end;
end;