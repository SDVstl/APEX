-- SEED DATA
declare
    l_id NUMBER;  -- used to hold the FK for the LOV_DETAILS table
begin
    begin
        -- get the FK for the Global Test Domain
        select ID into l_id from APXSHR_LOV_NAME where APP_ALIAS = '@APXSHR_GLOBAL_LOVS' and LOV_NA = 'Global Test Domain';

        INSERT INTO APXSHR_LOV_DETAILS (ID,LOV_NAME_ID,LOV_DISPLAY_VAL,LOV_DISPLAY_DESC,SORT_ORDER_NO,ACTIVE_IND,EFF_START_DA,EFF_END_DA,CREATED,CREATED_BY,UPDATED,UPDATED_BY,ALLOW_USER_DELETE_IND) VALUES (NULL,l_id,'Test Display Value 1','',10,'Y',to_date('', 'dd/mm/rrrr hh:mi:ss'),to_date('', 'dd/mm/rrrr hh:mi:ss'),to_date('25/06/2025 03:03:30', 'dd/mm/rrrr hh:mi:ss'),'nobody',to_date('25/06/2025 03:03:30', 'dd/mm/rrrr hh:mi:ss'),'nobody','N');

        INSERT INTO APXSHR_LOV_DETAILS (ID,LOV_NAME_ID,LOV_DISPLAY_VAL,LOV_DISPLAY_DESC,SORT_ORDER_NO,ACTIVE_IND,EFF_START_DA,EFF_END_DA,CREATED,CREATED_BY,UPDATED,UPDATED_BY,ALLOW_USER_DELETE_IND) VALUES (NULL,l_id,'Test Display Value 2','',20,'Y',to_date('', 'dd/mm/rrrr hh:mi:ss'),to_date('', 'dd/mm/rrrr hh:mi:ss'),to_date('25/06/2025 03:03:46', 'dd/mm/rrrr hh:mi:ss'),'nobody',to_date('25/06/2025 03:03:46', 'dd/mm/rrrr hh:mi:ss'),'nobody','N');
    
        exception when OTHERS then NULL;

    end; -- global domains

    begin

        select ID into l_id from APXSHR_LOV_NAME where APP_ALIAS = 'TEST' and LOV_NA = 'Test Domain';

        INSERT INTO APXSHR_LOV_DETAILS (ID,LOV_NAME_ID,LOV_DISPLAY_VAL,LOV_DISPLAY_DESC,SORT_ORDER_NO,ACTIVE_IND,EFF_START_DA,EFF_END_DA,CREATED,CREATED_BY,UPDATED,UPDATED_BY,ALLOW_USER_DELETE_IND) VALUES (NULL,l_id,'Test Display Value 1','',10,'Y',to_date('', 'dd/mm/rrrr hh:mi:ss'),to_date('', 'dd/mm/rrrr hh:mi:ss'),to_date('25/06/2025 03:03:30', 'dd/mm/rrrr hh:mi:ss'),'nobody',to_date('25/06/2025 03:03:30', 'dd/mm/rrrr hh:mi:ss'),'nobody','Y');

        INSERT INTO APXSHR_LOV_DETAILS (ID,LOV_NAME_ID,LOV_DISPLAY_VAL,LOV_DISPLAY_DESC,SORT_ORDER_NO,ACTIVE_IND,EFF_START_DA,EFF_END_DA,CREATED,CREATED_BY,UPDATED,UPDATED_BY,ALLOW_USER_DELETE_IND) VALUES (NULL,l_id,'Test Display Value 2','',20,'Y',to_date('', 'dd/mm/rrrr hh:mi:ss'),to_date('', 'dd/mm/rrrr hh:mi:ss'),to_date('25/06/2025 03:03:46', 'dd/mm/rrrr hh:mi:ss'),'nobody',to_date('25/06/2025 03:03:46', 'dd/mm/rrrr hh:mi:ss'),'nobody','Y');

        exception  when OTHERS then NULL;
    end; -- test domain
end; -- script